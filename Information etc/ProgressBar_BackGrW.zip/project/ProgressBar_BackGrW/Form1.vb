﻿Public Class Form1

    Dim fileTargetLocation As String
    Dim Destinydirectory As String

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        OpenFileDialog1.Title = "Select a file to copy"
        OpenFileDialog1.FileName = ""
        With OpenFileDialog1
            If .ShowDialog() = DialogResult.OK Then
                fileTargetLocation = .FileName
                Label1.Text = fileTargetLocation.ToString
            End If
        End With

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        FolderBrowserDialog1.Description = "Select destiny directory"
        With FolderBrowserDialog1
            If .ShowDialog() = DialogResult.OK Then
                Destinydirectory = .SelectedPath
                Label2.Text = Destinydirectory.ToString
            End If
        End With
    End Sub

    Private Sub BackgroundWorker1_DoWork(sender As Object, e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorker1.DoWork
        Dim parts As String() = fileTargetLocation.Split(New Char() {"\"c})
        Dim filename As String = parts(parts.Count - 1)
        Dim streamRead As New System.IO.FileStream(fileTargetLocation, System.IO.FileMode.Open)
        Dim streamWrite As New System.IO.FileStream(Destinydirectory + "\" + filename, IO.FileMode.Create, IO.FileAccess.Write, IO.FileShare.None)
        Dim lngLen As Long = streamRead.Length - 1
        Dim byteBuffer(4096) As Byte
        Dim intBytesRead As Integer

        setLabelTxt("Copy bytes : (0/" + (lngLen * 100).ToString + ")", Label3)

        While streamRead.Position < lngLen
            If (BackgroundWorker1.CancellationPending = True) Then
                e.Cancel = True
                Exit While
            End If
            BackgroundWorker1.ReportProgress(CInt(streamRead.Position / lngLen * 100))
            setLabelTxt("Copy bytes : (" + CInt(streamRead.Position).ToString + "/" + (lngLen * 100).ToString + ")", Label3)
            intBytesRead = (streamRead.Read(byteBuffer, 0, 4096))
            streamWrite.Write(byteBuffer, 0, intBytesRead)
        End While

        streamWrite.Flush()
        streamWrite.Close()
        streamRead.Close()

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Button1.Enabled = False
        Button2.Enabled = False
        BackgroundWorker1.RunWorkerAsync()
    End Sub

    Private Sub BackgroundWorker1_ProgressChanged(sender As Object, e As System.ComponentModel.ProgressChangedEventArgs) Handles BackgroundWorker1.ProgressChanged
        ProgressBar1.Value = e.ProgressPercentage
    End Sub

    Private Sub BackgroundWorker1_RunWorkerCompleted(sender As Object, e As System.ComponentModel.RunWorkerCompletedEventArgs) Handles BackgroundWorker1.RunWorkerCompleted
        If e.Cancelled = True Then
            MsgBox("Copy canceled!")

        Else
            MsgBox("Copy complete!")
        End If
        Button1.Enabled = True
        Button2.Enabled = True
    End Sub

    Private Sub setLabelTxt(ByVal text As String, ByVal lbl As Label)
        If lbl.InvokeRequired Then
            lbl.Invoke(New setLabelTxtInvoker(AddressOf setLabelTxt), text, lbl)
        Else
            lbl.Text = text
        End If
    End Sub
    Private Delegate Sub setLabelTxtInvoker(ByVal text As String, ByVal lbl As Label)

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If BackgroundWorker1.IsBusy Then
            BackgroundWorker1.CancelAsync()
        End If

    End Sub
End Class
